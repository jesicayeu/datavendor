<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
<div class="container-fluid">
<div class="row mb-2">
<div class="col-sm-6">
<h1><?= $data['title']; ?></h1>
</div>
</div>
</div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
<!-- Default box -->
<div class="card">
<div class="card-header">
<h3 class="card-title">Apa itu Data Vendor?</h3>
</div>
<div class="card-body">
Data Vendor adalah informasi apa pun yang terkait dengan vendor dan atau proses vendor tertentu,
mulai dari riset dan sumber daya,hingga onboarding dan manajemen vendor,dan pembayaran.
Semua informasi tentang vendor yang dimiliki dan digunakan oleh perusahaan anda dianggap sebagai vendor data.
Mengelola data vendor ini adalah bagian dari proses manajemen vendor;
ini termasuk kontrak vendor,detail kontak dan lokasi,persyaratan pembelian,dan hukum dokumentasi.
Ini terdiri dari mengumpulkan semua detail tentang vendor yang diperlukan untuk mendukung mereka,
berbisnis dengan mereka,dan mengukur serta melacak kinerja vendor dan pengeluaran terkait.
</div>
<!-- /.card-body -->
<div class="card-footer"> 
Vendor Footer
</div>
<!-- /.card-footer-->
</div>
<!-- /.card -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
